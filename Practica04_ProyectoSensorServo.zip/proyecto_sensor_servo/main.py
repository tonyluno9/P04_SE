from src.client.api_client import SensorAPIClient
from src.hardware.servo import ServoMotor
import time

def main():
    client = SensorAPIClient("http://localhost:5000")
    servo = ServoMotor(pin=17)
    try:
        while True:
            value = client.get_value()
            if value is not None:
                angle = (value / 100) * 180
                servo.set_angle(angle)
                print(f"Potenciómetro: {value:.2f}%  →  Servo: {angle:.1f}°")
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[MAIN] Finalizando ejecución...")
    finally:
        servo.cleanup()

if __name__ == "__main__":
    main()

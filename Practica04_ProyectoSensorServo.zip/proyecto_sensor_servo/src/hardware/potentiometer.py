"""
Módulo: potentiometer.py
Lee el valor del potenciómetro desde un ADC o simula datos si no hay hardware.
"""
import random

class Potentiometer:
    """Clase que obtiene valores analógicos de un potenciómetro."""

    def __init__(self, simulate: bool = True):
        self.simulate = simulate

    def read_value(self) -> float:
        if self.simulate:
            return round(random.uniform(0, 100), 2)
        return 0.0

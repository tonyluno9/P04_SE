"""
Módulo: servo.py
Controla un servo motor mediante PWM en una Raspberry Pi.
"""
import time
try:
    import RPi.GPIO as GPIO
except ImportError:
    class MockGPIO:
        BCM = BOARD = OUT = None
        def setmode(self, *_): pass
        def setup(self, *_): pass
        def PWM(self, *_): return self
        def start(self, *_): pass
        def ChangeDutyCycle(self, *_): pass
        def output(self, *_): pass
        def cleanup(self): pass
    GPIO = MockGPIO()

class ServoMotor:
    def __init__(self, pin: int):
        self.pin = pin
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(pin, GPIO.OUT)
        self.pwm = GPIO.PWM(pin, 50)
        self.pwm.start(0)
        print(f"[Servo] Inicializado en pin {pin}")

    def set_angle(self, angle: float):
        if angle < 0: angle = 0
        if angle > 180: angle = 180
        duty = 2 + (angle / 18)
        GPIO.output(self.pin, True)
        self.pwm.ChangeDutyCycle(duty)
        time.sleep(0.4)
        GPIO.output(self.pin, False)
        self.pwm.ChangeDutyCycle(0)
        print(f"[Servo] → {angle:.2f}°")

    def cleanup(self):
        self.pwm.stop()
        GPIO.cleanup()
        print("[Servo] Limpieza completada")

import requests
import time

class SensorAPIClient:
    def __init__(self, base_url: str):
        self.base_url = base_url

    def get_value(self) -> float | None:
        try:
            response = requests.get(f"{self.base_url}/api/sensor", timeout=3)
            response.raise_for_status()
            data = response.json()
            return data.get("porcentaje", 0.0)
        except requests.RequestException as e:
            print(f"[Cliente] Error al conectar con API: {e}")
            return None

    def loop_read(self, interval=1):
        while True:
            value = self.get_value()
            if value is not None:
                print(f"[Cliente] Valor: {value}%")
            time.sleep(interval)

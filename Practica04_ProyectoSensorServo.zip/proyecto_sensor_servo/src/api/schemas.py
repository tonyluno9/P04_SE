sensor_schema = {
    "type": "object",
    "properties": {
        "porcentaje": {"type": "number"},
        "unidad": {"type": "string"},
        "descripcion": {"type": "string"}
    },
    "required": ["porcentaje", "unidad"]
}

from flask import Flask, jsonify
from src.hardware.potentiometer import Potentiometer

app = Flask(__name__)
sensor = Potentiometer(simulate=True)

@app.route("/api/sensor", methods=["GET"])
def get_sensor_data():
    value = sensor.read_value()
    return jsonify({
        "porcentaje": value,
        "unidad": "%",
        "descripcion": "Valor actual del potenciómetro"
    })

@app.route("/")
def index():
    return jsonify({
        "mensaje": "API del Sensor de Potenciómetro",
        "endpoints": ["/api/sensor"]
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

# API del Sensor de Potenciómetro

## GET /api/sensor
Devuelve el valor actual del potenciómetro.

```json
{
  "porcentaje": 62.45,
  "unidad": "%",
  "descripcion": "Valor actual del potenciómetro"
}
```

## Códigos de estado
- 200 OK
- 500 INTERNAL SERVER ERROR
